package com.FinalProject.SweetHub.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.FinalProject.SweetHub.model.Category;

public interface CategoryRepository extends JpaRepository<Category,Integer>{

}
