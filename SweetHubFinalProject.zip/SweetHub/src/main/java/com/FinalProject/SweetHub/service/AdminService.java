package com.FinalProject.SweetHub.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.FinalProject.SweetHub.model.Admin;
import com.FinalProject.SweetHub.model.Category;
import com.FinalProject.SweetHub.model.Userdet;
import com.FinalProject.SweetHub.repository.AdminRepository;
import com.FinalProject.SweetHub.repository.CategoryRepository;
import com.FinalProject.SweetHub.repository.UserdetRepository;

@Service
public class AdminService {

	@Autowired
	AdminRepository adminRepository;


	public void addAdmindet(Admin admindet) {
		adminRepository.save(admindet);
	}


	public Admin getAdmindetByAdminname(String adminname) {
		return (adminRepository.findByAdminname(adminname));
	}

}
