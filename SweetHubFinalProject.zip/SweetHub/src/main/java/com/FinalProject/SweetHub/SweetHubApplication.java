package com.FinalProject.SweetHub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SweetHubApplication {

	public static void main(String[] args) {
		SpringApplication.run(SweetHubApplication.class, args);
		
	}

}
