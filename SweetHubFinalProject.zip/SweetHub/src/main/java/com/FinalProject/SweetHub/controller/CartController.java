package com.FinalProject.SweetHub.controller;


import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import com.FinalProject.SweetHub.model.Product;
import com.FinalProject.SweetHub.service.ProductService;
@Controller
public class CartController {
	
		@Autowired
		ProductService productService;
		
		double sumOfAll=0;
		public static Map<Product,Integer> cartList;
		
		static {
			cartList = new LinkedHashMap<>();
		}
				
		@GetMapping("/addToCart/{id}")
		public String addToCart(HttpServletRequest request,@PathVariable int id) {
			HttpSession session = request.getSession();
			if (session.getAttribute("username") == null) {
	            return "userLogin";
	        }
			
			Set<Long> a = new LinkedHashSet<>();
			Set<Product> b=cartList.keySet();
			Product product = productService.getProductById(id).get();
			for (Product p:b) {
				a.add(p.getId());
			}
			if(a.contains(product.getId())) {
				for(Product p:b) {
					if(p.getId().equals(product.getId())) {
						Integer val = cartList.get(p);
						cartList.put(p, val+1);
					}
				}
				
			}
			else {
				cartList.put(product,1);
			}
			
			return "redirect:/shop";
		}
		
		@GetMapping("/cart")
		public String cartGet(HttpServletRequest request,Model model) {
			HttpSession session = request.getSession();
			if (session.getAttribute("username") == null) {
	            // User is not authenticated, redirect to login page
	            return "userLogin";
	        }
			
			model.addAttribute( "cartCount", cartList.size());
			Set<Product> lst=cartList.keySet();
			sumOfAll=0;
			for(Product k:lst) {
				sumOfAll+=k.getPrice()*(cartList.get(k));	
			}
			model.addAttribute( "total",sumOfAll);
			model.addAttribute("listing",cartList);
			return "cart";

		}
		
		@GetMapping("/cart/removeItem/{index}")
		public String cartItemRemove(HttpServletRequest request,@PathVariable Long index) { 
			HttpSession session = request.getSession();
			if (session.getAttribute("username") == null) {
	            // User is not authenticated, redirect to login page
	            return "userLogin";
	        }
			Set<Product> b=cartList.keySet();
			for(Product p:b) {
				if(p.getId().equals(index)) {
					cartList.remove(p);
					break;
				}
			}
			return "redirect:/cart";
		}

		@GetMapping("/checkout")
		public String checkout (HttpServletRequest request,Model model) {
			HttpSession session = request.getSession();
			if (session.getAttribute("username") == null) {
	            return "userLogin";
	        }
				model.addAttribute( "total", sumOfAll);
				return "checkout";
		}
		
		

		@GetMapping("/payment")
		public String paymentCheck(HttpServletRequest request,Model model) {
			HttpSession session = request.getSession();
			if (session.getAttribute("username") == null) {
	            // User is not authenticated, redirect to login page
	            return "userLogin";
	        }
			model.addAttribute( "cartCount", cartList.size());
			model.addAttribute( "total",sumOfAll);
			model.addAttribute("listing", cartList);
			model.addAttribute( "total", sumOfAll);
				return "payment";
		}
	
	}


