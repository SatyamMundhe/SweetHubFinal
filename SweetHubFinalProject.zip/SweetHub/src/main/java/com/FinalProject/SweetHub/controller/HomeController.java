package com.FinalProject.SweetHub.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.FinalProject.SweetHub.model.Userdet;
import com.FinalProject.SweetHub.service.CategoryService;
import com.FinalProject.SweetHub.service.ProductService;
import com.FinalProject.SweetHub.service.UserdetService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class HomeController {

	@Autowired
	CategoryService  categoryService;
	@Autowired
	ProductService  productService;
	@Autowired
	UserdetService  userdetService;
	String usernameforclass = "";
	

	
	@GetMapping("/shop")
	public String shop(HttpServletRequest request,Model model) {
		HttpSession session = request.getSession();
		if (session.getAttribute("username") == null) {
            // User is not authenticated, redirect to login page
            return "userLogin";
        }
		model.addAttribute("categories",categoryService.getAllCategory());
		model.addAttribute("products",productService.getAllProduct());
		model.addAttribute( "cartCount", CartController.cartList.size());
		return "shop";
	}
	@GetMapping("/shop/category/{id}")
	public String shopByCategory(HttpServletRequest request,Model model,@PathVariable int  id) {
		HttpSession session = request.getSession();
		if (session.getAttribute("username") == null) {
            // User is not authenticated, redirect to login page
            return "userLogin";
        }
		model.addAttribute("categories",categoryService.getAllCategory());
		model.addAttribute("products",productService.getAllProductsByCategoryId(id));
		model.addAttribute( "cartCount", CartController.cartList.size());
		System.out.println("shop"+CartController.cartList.size());
		return "shop";
	}
	@GetMapping("/shop/viewproduct/{id}")
	public String viewProduct(HttpServletRequest request,Model model,@PathVariable int  id) {
		HttpSession session = request.getSession();
		if (session.getAttribute("username") == null) {
            // User is not authenticated, redirect to login page
            return "userLogin";
        }
		model.addAttribute("product",productService.getProductById(id).get());
		model.addAttribute( "cartCount", CartController.cartList.size());
		return "viewProduct";
	}
	@GetMapping("/contact")
	public String contact(HttpServletRequest request,Model model ) {
		HttpSession session = request.getSession();
		if (session.getAttribute("username") == null) {
            // User is not authenticated, redirect to login page
            return "userLogin";
        }
		return("contact");
	}

	
}
