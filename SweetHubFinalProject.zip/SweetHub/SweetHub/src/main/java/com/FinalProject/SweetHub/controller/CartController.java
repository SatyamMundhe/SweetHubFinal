package com.FinalProject.SweetHub.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.FinalProject.SweetHub.global.GlobalData;
import com.FinalProject.SweetHub.model.Product;
import com.FinalProject.SweetHub.service.ProductService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
@Controller
public class CartController {
		@Autowired
		ProductService productService;
		
		@GetMapping("/addToCart/{id}")
		public String addToCart(HttpServletRequest request,@PathVariable int id) {
			HttpSession session = request.getSession();
			if (session.getAttribute("username") == null) {
	            return "userLogin";
			}
			GlobalData.cart.add(productService.getProductById(id).get());
			return "redirect:/shop";
			
		}
		
		@GetMapping("/cart")
		public String cartGet(HttpServletRequest request,Model model) {
			HttpSession session = request.getSession();
			if (session.getAttribute("username") == null) {
	            // User is not authenticated, redirect to login page
	            return "userLogin";
	        }
			model.addAttribute( "cartCount", GlobalData.cart.size());
			model.addAttribute( "total", GlobalData.cart.stream().mapToDouble(Product::getPrice).sum());
			model.addAttribute("cart", GlobalData.cart);
			return "cart";

		}
		
		@GetMapping("/cart/removeItem/{index}")
		public String cartItemRemove(HttpServletRequest request,@PathVariable int index) { 
			HttpSession session = request.getSession();
			if (session.getAttribute("username") == null) {
	            // User is not authenticated, redirect to login page
	            return "userLogin";
	        }
			GlobalData.cart.remove(index);
			return "redirect:/cart";
		}

		@GetMapping("/checkout")
		public String checkout (HttpServletRequest request,Model model) {
			HttpSession session = request.getSession();
			if (session.getAttribute("username") == null) {
	            // User is not authenticated, redirect to login page
	            return "userLogin";
	        }
				model.addAttribute( "total", GlobalData.cart.stream().mapToDouble(Product::getPrice).sum());
				return "checkout";
		}
		
		
		
		

		@GetMapping("/payment")
		public String paymentCheck(HttpServletRequest request,Model model) {
			HttpSession session = request.getSession();
			if (session.getAttribute("username") == null) {
	            // User is not authenticated, redirect to login page
	            return "userLogin";
	        }
			model.addAttribute( "cartCount", GlobalData.cart.size());
			model.addAttribute( "total", GlobalData.cart.stream().mapToDouble(Product::getPrice).sum());
			model.addAttribute("cart", GlobalData.cart);
			model.addAttribute( "total", GlobalData.cart.stream().mapToDouble(Product::getPrice).sum());
				return "payment";
		}
	
	}


