package com.FinalProject.SweetHub.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.FinalProject.SweetHub.model.Admin;
import com.FinalProject.SweetHub.repository.AdminRepository;

@Service
public class AdminService {

	@Autowired
	AdminRepository adminRepository;


	public void addAdmindet(Admin admindet) {
		adminRepository.save(admindet);
	}


	public Admin getAdmindetByAdminname(String adminname) {
		return (adminRepository.findByAdminname(adminname));
	}

}
